package personal_center;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

public class User implements Parcelable {
    private int user_id;

    private String phone_num;

    private String user_name;

    private String gender;

    private String email;

    private String birthday;

    private String icon;

    public void setUser_id(int user_id){
        this.user_id = user_id;
    }
    public int getUser_id(){
        return this.user_id;
    }
    public void setPhone_num(String phone_num){
        this.phone_num = phone_num;
    }
    public String getPhone_num(){
        return this.phone_num;
    }
    public void setUser_name(String user_name){
        this.user_name = user_name;
    }
    public String getUser_name(){
        return this.user_name;
    }
    public void setGender(String gender){
        this.gender = gender;
    }
    public String getGender(){
        return this.gender;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public String getEmail(){
        return this.email;
    }
    public void setBirthday(String birthday){
        this.birthday = birthday;
    }
    public String getBirthday(){
        return this.birthday;
    }
    public void setIcon(String icon){
        this.icon = icon;
    }
    public String getIcon(){
        return this.icon;
    }
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        Log.i("UserParcelMSG", "ParcelableCartoon::writeToParcel");
        dest.writeString(user_name);
        dest.writeString(birthday);
        dest.writeString(email);
        dest.writeString(gender);
        dest.writeString(icon);
        dest.writeString(phone_num);
        dest.writeInt(user_id);
    }

    public static final Parcelable.Creator<User> CREATOR =
            new Parcelable.Creator<User>(){
        @Override
        public User createFromParcel(Parcel source) {
            Log.i("UserParcelMSG", "ParcelableCartoon::Parcelable.Creator::createFromParcel");
            User user = new User();
            user.setUser_name(source.readString());
            user.setBirthday(source.readString());
            user.setEmail(source.readString());
            user.setGender(source.readString());
            user.setIcon(source.readString());
            user.setPhone_num(source.readString());
            user.setUser_id(source.readInt());
            /*user.user_name = source.readString();
            user.birthday = source.readString();
            user.email = source.readString();
            user.gender = source.readString();
            user.icon = source.readString();
            user.phone_num = source.readString();
            user.user_id = source.readInt();*/
            return user;
        }

        @Override
        public User[] newArray(int size) {
            Log.i("UserParcelMSG", "ParcelableCartoon::Parcelable.Creator::newArray");
            return new User[size];
        }

    };
    @Override
    public int describeContents() {
        return 0;
    }

}


