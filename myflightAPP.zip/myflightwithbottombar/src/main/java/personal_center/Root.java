package personal_center;

public class Root
{
    private int login_status;

    private String info;

    private User user;

    public void setLogin_status(int login_status){
        this.login_status = login_status;
    }
    public int getLogin_status(){
        return this.login_status;
    }
    public void setInfo(String info){
        this.info = info;
    }
    public String getInfo(){
        return this.info;
    }
    public void setUser(User user){
        this.user = user;
    }
    public User getUser(){
        return this.user;
    }
}