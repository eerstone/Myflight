package personal_center;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myflightwithbottombar.R;
import com.google.gson.Gson;


import org.json.JSONObject;

import java.io.IOException;
import java.io.Reader;
import java.net.URLDecoder;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import source.DEFINE;


public class RegisterActivity extends AppCompatActivity {
    private Button ACB;//area_code_button
    private EditText PhNum;//phone_number
    private EditText PSW;//password
    private EditText rePSW;//confirm_password
    private EditText VC;//verify_code
    private Button VCB;//verify_codeb_button
    private Button RB;//register_button
    private String correct_VerifyCode;


    private String responseData = "";
    private Reader responseReader ;
    private final Gson gson = new Gson();

    private static final int VERIFY = 0;
    private static final int REGISTER = 1;




    @Override
    protected void onCreate(Bundle saveInstanceState){
        if (getSupportActionBar() != null){
            getSupportActionBar().hide();
        }
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_register1);
        init();
        VCB.setOnClickListener(verifyButtonListener);
        RB.setOnClickListener(registerButtonListener);
    }


    private  void init(){
        ACB = (Button)findViewById(R.id.areaCode_button);
        PhNum = (EditText)findViewById(R.id.register_phone_num);
        PSW = (EditText)findViewById(R.id.register_password);
        rePSW = (EditText)findViewById(R.id.register_password_confirmation);
        VC = (EditText)findViewById(R.id.verifycode);
        VCB = (Button)findViewById(R.id.verifycode_button);
        RB = (Button)findViewById(R.id.next_step1);
        //设置输入位数等组件属性
        VC.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
    }

    //verify button listener
    public View.OnClickListener verifyButtonListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String phone_num = PhNum.getText().toString().trim();
            postVerifyRequest(phone_num);
        }
    };
    public void postVerifyRequest(String phone_num){

        final FormBody formbody = new FormBody.Builder()
                .add("phone_num",phone_num)
                .build();
        final Request request1 = new Request.Builder()
                .url(DEFINE.serve_addr+DEFINE.verifyAPI/*+"?phone_num="+phone_num*/)
                .post(formbody)
                .build();
        final OkHttpClient client = new OkHttpClient();

        new Thread(new Runnable() {
            @Override
            public void run() {
                Response response = null;
                try{
                    LogInfo(request1.method());
                    response = client.newCall(request1).execute();
                    if(response.isSuccessful()){
                        LogInfo("Verify Connect successful!");
                    }
                    else{
                        LogInfo("fail to Verify Connect!");
                        throw new IOException("Unexpected Code"+response);
                    }
                    Message msg = mHandler.obtainMessage();
                    responseData = response.body().string();
                    msg.what = VERIFY;
                    mHandler.sendEmptyMessage(msg.what);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    //register button listener
    public View.OnClickListener registerButtonListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String phone_num = PhNum.getText().toString().trim();
            String psw = PSW.getText().toString().trim();
            String repsw = rePSW.getText().toString().trim();
            String verifyCode = VC.getText().toString().trim();
            //判断输入是否为空
            if(TextUtils.isEmpty(phone_num)){
                ToastShow("请输入手机号");
            }else if(TextUtils.isEmpty(psw)) {
                ToastShow("请输入密码");
            }else if(TextUtils.isEmpty(repsw)){
                ToastShow("请再次输入密码");
            }
            else if(TextUtils.isEmpty(verifyCode)){
                ToastShow("请输入验证码");
            }
            //判断手机号是否合法  库：libphonenumber
            /*else if(false){
                //do sth
            }*/
            //判断确认密码是否与密码一致
            else if(!psw.equals(repsw)){
                ToastShow("两次输入密码不一致");
            }
            //输入合法 向后端发送post请求
            else{
                postregisterRequest(phone_num,verifyCode,psw);
            }

        }
    };

    private void postregisterRequest(String phone_num,String VerifiedCode,String psw){

        FormBody reqBody = new FormBody.Builder()
                .add("phone_num",phone_num)
                .add("VerifiedCode",VerifiedCode)
                .add("pwd",psw)
                .build();

        final Request request = new Request.Builder()
                .url(DEFINE.serve_addr+DEFINE.registerAPI/*+"?phone_num="+phone_num+"&pwd="+psw+
                        "&VerifiedCode="+VerifiedCode*/)
                .post(reqBody)
                .build();

        final OkHttpClient client = new OkHttpClient();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Response response = null;
                try {
                    LogInfo(request.method());
                    response = client.newCall(request).execute();
                    if(response.isSuccessful()){
                        LogInfo("Register Connect successful!");
                        //System.out.println("connect successful!");
                    }
                    else{
                        LogInfo("fail to Rgister Connect!");
                        throw new IOException("Unexpected Code"+response);
                    }
                    //response 法
                    Message msg = mHandler.obtainMessage();
                    responseData = response.body().string();
                    //responseReader = response.body().charStream();
                    msg.what = REGISTER;
                    mHandler.sendEmptyMessage(msg.what);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();

    }

    Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            try{
                responseData = URLDecoder.decode(responseData, "utf-8");
                switch(msg.what){
                    case VERIFY:
                        JSONObject rootObject1 = new JSONObject(responseData);
                        int code_status = rootObject1.getInt("CodeStatus");
                        String massage = rootObject1.getString("msg");
                        ToastShow(massage);
                        break;
                    case REGISTER:
                        //responseData = (String) msg.obj;
                        //RB.setText(responseData);
                        JSONObject rootObject = new JSONObject(responseData);
                        int register_status =rootObject.getInt("register_status");
                        switch (register_status) {
                            case 0:
                                Toast.makeText(RegisterActivity.this, "注册成功", Toast.LENGTH_SHORT).show();
                                User user = new User();
                                user.setPhone_num(PhNum.getText().toString().trim());
                                user.setUser_name(PhNum.getText().toString().trim());
                                Intent data = new Intent();
                                Bundle bundle = new Bundle();
                                bundle.putParcelable("userObject_RG2LG",user);
                                data.putExtras(bundle);
                                setResult(DEFINE.REGISTER_END, data);
                                finish();
                                break;
                            case 1:
                                ToastShow("账号已存在");
                                break;
                            case 2:
                                ToastShow("验证码错误");
                                break;
                            default:
                                ToastShow("未知错误，请稍后重试");
                        }
                        break;
                    default:
                        break;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return false;
        }
    });





    private void ToastShow(String content){
        Toast.makeText(RegisterActivity.this,content,Toast.LENGTH_SHORT).show();
    }
    private void LogInfo(String info){
        Log.i("registerLog",info);
    }

}
