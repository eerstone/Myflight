package personal_center;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myflightwithbottombar.R;

import org.json.JSONObject;

import java.io.IOException;
import java.net.URLDecoder;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import source.DEFINE;

public class UserInforActivity extends AppCompatActivity {
    private User user;
    private EditText userNameET;
    private EditText genderET;
    private EditText birthdayET;
    private EditText phoneET;
    private EditText emailET;
    private Button saveButton;


    private String responseData="";

    private static final int SAVE = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (getSupportActionBar() != null){
            getSupportActionBar().hide();
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userinfomation);
        init();
        saveButton.setOnClickListener(saveClickListener);
    }

    private void init(){
        user = getIntent().getParcelableExtra("userObject_PC2UI");
        userNameET = (EditText)findViewById(R.id.et_nickname);
        genderET = (EditText)findViewById(R.id.et_gender);
        birthdayET = (EditText)findViewById(R.id.et_birthday);
        phoneET = (EditText)findViewById(R.id.et_phone);
        emailET = (EditText)findViewById(R.id.et_email);
        saveButton = (Button)findViewById(R.id.button_saveInfo);
        updateViewText();
    }

    public void updateViewText(){
        userNameET.setText(user.getUser_name());
        genderET.setText(user.getGender());
        birthdayET.setText(user.getBirthday());
        phoneET.setText(user.getPhone_num());
        emailET.setText(user.getEmail());
    }
    private void updateBasicInfo(){
        user.setUser_name(userNameET.getText().toString().trim());
        user.setGender(genderET.getText().toString().trim());
        user.setBirthday(birthdayET.getText().toString().trim());
        user.setPhone_num(phoneET.getText().toString().trim());
        user.setEmail(emailET.getText().toString().trim());
        updateViewText();
    }

    private View.OnClickListener saveClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            OkHttpClient client = new OkHttpClient();
            FormBody formBody = new FormBody.Builder()
                    .add("user_id",String.valueOf(user.getUser_id()))
                    .add("user_name",userNameET.getText().toString().trim())
                    .add("phone_num",phoneET.getText().toString().trim())
                    .add("gender",genderET.getText().toString().trim())
                    .add("email",emailET.getText().toString().trim())
                    .add("birthday",birthdayET.getText().toString().trim())
                    .build();
            Request request = new Request.Builder()
                    .url(DEFINE.serve_addr+DEFINE.modifyUserInfoAPI)
                    .post(formBody)
                    .build();

            new Thread(new Runnable() {
                @Override
                public void run() {
                    try{
                        Response response = client.newCall(request).execute();
                        if(response.isSuccessful()){
                            LogInfo("SaveInfo Connect successful!");
                            //System.out.println("connect successful!");
                        }
                        else{
                            LogInfo("SaveInfo to Rgister Connect!");
                            throw new IOException("Unexpected Code"+response);
                        }
                        Message msg = mHandler.obtainMessage();
                        responseData = response.body().string();
                        msg.what = SAVE;
                        mHandler.sendEmptyMessage(msg.what);

                    }catch (IOException e){
                        e.printStackTrace();
                    }
                }
            }).start();

        }
    };

    Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            try{
                switch(msg.what){
                    case SAVE:
                        responseData = URLDecoder.decode(responseData, "utf-8");
                        JSONObject rootObject = new JSONObject(responseData);
                        int isSuccessful =rootObject.getInt("issucceed");
                        if(isSuccessful==1){
                            ToastShow("保存成功");
                            updateBasicInfo();
                            Intent intant = new Intent();
                            Bundle bundle = new Bundle();
                            bundle.putParcelable("userObject_UI2PC",user);
                            intant.putExtras(bundle);
                            setResult(DEFINE.USERINFO_END,intant);
                            finish();
                        }else{
                            ToastShow("保存失败，稍后重试");
                        }
                        break;
                    default:
                        break;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return false;
        }
    });

    private void ToastShow(String content){
        Toast.makeText(UserInforActivity.this,content,Toast.LENGTH_SHORT).show();
    }
    private void LogInfo(String info){
        Log.i("UserInfoLog",info);
    }


}
