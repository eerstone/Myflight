package personal_center;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.myflightwithbottombar.MainActivity2;
import com.example.myflightwithbottombar.R;

import source.DEFINE;

public class PersonalCenterFragment extends Fragment {
    private User user;
    private Button quitButton;
    private LinearLayout thisframe;
    private TextView tv_userName;
    private Button UserInfoButton;
    private Button MytripButton;
    private MyQuitListener MQL;

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //不同的Activity对应不同的布局
        View view = inflater.inflate(R.layout.activity_personal_center, container, false);
        init(view);
        quitButton.setOnClickListener(quitClickListener);
        UserInfoButton.setOnClickListener(userInfoClickListener);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    private void init(View view){
        Bundle bundle = getArguments();
        user = bundle.getParcelable("userObject_M2PC");
        quitButton = (Button) view.findViewById(R.id.quitbutton);
        thisframe = (LinearLayout) view.findViewById(R.id.personal_center_frame);
        tv_userName = (TextView)view.findViewById(R.id.PSC_username);
        UserInfoButton = (Button)view.findViewById(R.id.userInfoButton);
        MytripButton = (Button)view.findViewById(R.id.MytripButton);
        MytripButton.setVisibility(View.GONE);
        tv_userName.setText(user.getUser_name());
        MQL = (MyQuitListener)getActivity();
    }

    private View.OnClickListener userInfoClickListener = new View.OnClickListener(){
        @Override
        public void onClick(View view){
          Intent intant = new Intent(getActivity(),UserInforActivity.class);
          Bundle bundle = new Bundle();
          bundle.putParcelable("userObject_PC2UI",user);
          intant.putExtras(bundle);
          startActivityForResult(intant, DEFINE.USERINFO_BEGIN);
        }
    };

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if( requestCode==DEFINE.USERINFO_BEGIN && resultCode==DEFINE.USERINFO_END ) {
            //data就是下一个页面的意图
            user = intent.getParcelableExtra("userObject_UI2PC");
            tv_userName.setText(user.getUser_name());
        }
    }

    private View.OnClickListener quitClickListener = new View.OnClickListener(){
      @Override
      public void onClick(View view){
          /*Intent intent = new Intent();
          intent.setClass(getActivity(), LoginActivity.class);
          startActivityForResult(intent,11);*/
          MQL.restartLoginActivity();
          MainActivity2.setLoginFlagOFF();
          //Toast.makeText(getActivity(),getActivity().toString(),Toast.LENGTH_SHORT).show();
          thisframe.setVisibility(View.GONE);
          //getActivity().onBackPressed();
      }
    };
    public interface MyQuitListener{
        public void restartLoginActivity();
    }

}
