package personal_center;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.myflightwithbottombar.MainActivity2;
import com.example.myflightwithbottombar.R;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.io.IOException;
import java.io.Reader;
import java.net.URLDecoder;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import source.DEFINE;


public class LoginActivity extends AppCompatActivity{
    private EditText userNameView;
    private EditText PasswordView;
    private Button PwdButton;
    private Button CodeButton;
    private LinearLayout VerifyLayout;
    private Button VerifyButton;
    private EditText VerifyCodeView;
    private Button LoginButton;
    private Button RegisterButton;
    private Button ForgetPwdButton;

    private String responseData = "";
    private Reader responseReader ;
    private int loginType; // 0 : password ; 1: verify code


    private static final int VERIFY = 0;
    private static final int LOGIN = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (getSupportActionBar() != null){
            getSupportActionBar().hide();
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();
        /*WebView wv = (WebView)findViewById(R.id.webview);
        wv.loadUrl("http://www.baidu.com");*/
        PwdButton.setOnClickListener(byPswClickListener);
        CodeButton.setOnClickListener(byCodeClickListener);
        VerifyButton.setOnClickListener(verifyClickListener);
        LoginButton.setOnClickListener(loginClickListener);
        RegisterButton.setOnClickListener(registerClickListener);

    }

    public void init(){
        userNameView = (EditText)findViewById(R.id.name);
        PasswordView = (EditText)findViewById(R.id.login_password);
        RegisterButton = (Button)findViewById(R.id.to_register);
        LoginButton = (Button)findViewById(R.id.login_button);
        PwdButton = (Button)findViewById(R.id.pwdbutton);
        CodeButton = (Button)findViewById(R.id.codeButton);
        VerifyLayout = (LinearLayout)findViewById(R.id.verifyLayout);
        VerifyButton = (Button)findViewById(R.id.verifycode_button);
        VerifyCodeView = (EditText) findViewById(R.id.verifycode);
        ForgetPwdButton = (Button) findViewById(R.id.forget_pass);
    }

    public View.OnClickListener byPswClickListener = new View.OnClickListener(){
        @Override
        public void onClick(View v){
            VerifyLayout.setVisibility(View.GONE);
            PasswordView.setVisibility(View.VISIBLE);
            loginType = 0;
        }
    };
    public View.OnClickListener byCodeClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            VerifyLayout.setVisibility(View.VISIBLE);
            PasswordView.setVisibility(View.GONE);
            loginType = 1;
        }
    };
    public View.OnClickListener verifyClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String phone_num = userNameView.getText().toString().trim();
            postVerifyRequest(phone_num);
        }
    };

    public void postVerifyRequest(String phone_num){
        new Thread(new Runnable() {
            @Override
            public void run() {
                FormBody reqBody = new FormBody.Builder()
                        .add("phone_num",phone_num)
                        .build();
                Request request = new Request.Builder()
                        .url(DEFINE.serve_addr+DEFINE.verifyAPI/*+"?phone_num="+phone_num*/)
                        .post(reqBody)
                        .build();
                OkHttpClient client = new OkHttpClient();
                Response response = null;
                try{
                    response = client.newCall(request).execute();
                    if(response.isSuccessful()){
                        Log.i("loginLog","Verify Connect successful!");
                        //System.out.println("connect successful!");
                    }
                    else{
                        Log.i("loginLog","fail to Verify Connect!");
                        throw new IOException("Unexpected Code"+response);
                    }
                    Message msg = mHandler.obtainMessage();
                    responseData = response.body().string();
                    msg.what = VERIFY;
                    mHandler.sendEmptyMessage(msg.what);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public View.OnClickListener loginClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(loginType == 0){//账号密码登录

                String phone_num = userNameView.getText().toString().trim();
                String pwd =  PasswordView.getText().toString().trim();
                //判断是否输入为空
                if(TextUtils.isEmpty(phone_num)){
                    ToastShow("请输入手机号");
                }else if(TextUtils.isEmpty(pwd)) {
                    ToastShow("请输入密码");
                }
                //判断手机号是否合法  库：libphonenumber
                else if(false){
                }
                //输入合法 向后端发送post请求
                else{
                    postLoginRequest("0",phone_num,"",pwd);
                }
            }
            else if(loginType == 1){//验证码登录
                String phone_num = userNameView.getText().toString().trim();
                String verify_code = VerifyCodeView.getText().toString().trim();
                //判断是否输入为空
                if(TextUtils.isEmpty(phone_num)){
                    ToastShow("请输入手机号");
                }else if(TextUtils.isEmpty(verify_code)) {
                    ToastShow("请输入验证码");
                }
                //判断手机号是否合法  库：libphonenumber
                else if(false){
                }
                //输入合法 向后端发送post请求
                else{
                    postLoginRequest("1",phone_num,verify_code,"");
                }

            }
            else{
                Log.e("loginLog","loginType is neither 0 nor 1!");
            }

        }
    };

    private void postLoginRequest(String type,String phone_num,String VerifiedCode,String psw){

        new Thread(new Runnable() {
            @Override
            public void run() {

                FormBody reqBody = new FormBody.Builder()
                        .add("type",type)
                        .add("phone_num",phone_num)
                        .add("VerifiedCode",VerifiedCode)
                        .add("pwd",psw)
                        .build();
                Request request = new Request.Builder()
                        .url(DEFINE.serve_addr+DEFINE.loginAPI/*+"?type="+type+"&phone_num
                        ="+phone_num+"111111"
                                "&VerifiedCode="+VerifiedCode+"&pwd="+psw*/)
                        .post(reqBody)
                        .build();
                OkHttpClient client = new OkHttpClient();
                Response response = null;
                try {
                    response = client.newCall(request).execute();

                    if(response.isSuccessful()){
                        Log.i("loginLog","Login Connect successful!");
                        //System.out.println("connect successful!");
                    }
                    else{
                        Log.i("loginLog","fail to Login Connect!");
                        throw new IOException("Unexpected Code"+response);
                    }

                    //response 法
                    Message msg = mHandler.obtainMessage();
                    responseData = response.body().string();
                    //responseReader = response.body().charStream();
                    msg.what = LOGIN;
                    mHandler.sendEmptyMessage(msg.what);

                    //callback 法
                    /*Call call = client.newCall(request);
                    call.enqueue(new Callback() {
                        @Override
                        public void onFailure(Call call, IOException e) {
                            e.printStackTrace();
                        }

                        @Override
                        public void onResponse(Call call,Response response) throws IOException {
                            Message msg = mHandler.obtainMessage();
                            msg.what = LOGIN;
                            msg.obj = response.body().string();
                            mHandler.sendMessage(msg);
                        }
                    });*/

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            try{
                responseData = URLDecoder.decode(responseData, "utf-8");
                switch(msg.what){
                    case VERIFY:
                        JSONObject rootObject1 = new JSONObject(responseData);
                        int code_status = rootObject1.getInt("CodeStatus");
                        String massage = rootObject1.getString("msg");
                        ToastShow(massage);
                        break;
                    case LOGIN:
                        //responseData = (String) msg.obj;
                        //LoginButton.setText(responseData);
                        //直接解析
                        JSONObject rootObject = new JSONObject(responseData);
                        int login_status = rootObject.getInt("login_status");
                        //gson法解析
                        /*Root root;
                        Gson gson = new Gson();
                        root = gson.fromJson(responseData,Root.class);
                        LogInfo(root.getInfo());
                        LogInfo(String.valueOf(root.getLogin_status()));
                        LogInfo(String.valueOf(root.getUser().getUser_id()));
                        LogInfo(root.getUser().getPhone_num());*/
                        switch (login_status) {
                            case 0:
                                JSONObject userObject = rootObject.getJSONObject("user");
                                Gson gs = new Gson();
                                User user = gs.fromJson(userObject.toString(),User.class);
                                sendBackANDFinish(user);
                                break;
                            case 1:
                                ToastShow("账号不存在");
                                break;
                            case 2:
                                ToastShow("验证码错误");
                                break;
                            case 3:
                                ToastShow("密码错误，请重新输入");
                                break;
                            default:
                                ToastShow("未知错误，请稍后重试");
                        }

                        break;
                    default:
                        break;

                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return false;
        }
    });
    /*Gist gist = gson.fromJson(responseData,Gist.class);
                            for (Map.Entry<String, String> entry : gist.map.entrySet()) {
                                LogInfo(entry.getKey());
                                LogInfo(entry.getValue());
                            }*/
    /*static class Gist {
        Map<String, String> map;
    }*/

    /*static class GistFile {
        String content;
    }*/
    private void sendBackANDFinish(User user){
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        bundle.putParcelable("userObject_LG2M",user);
        intent.putExtras(bundle);
        setResult(DEFINE.LOGIN_END,intent);
        MainActivity2.setLoginFlagOn();
        ToastShow("恭喜，登录成功");
        this.finish();
    }

    public View.OnClickListener registerClickListener = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivityForResult(intent,DEFINE.REGISTER_BEGIN);

        }
    };
    protected void onActivityResult(int requestCode, int resultCode, Intent intant) {
        super.onActivityResult(requestCode, resultCode, intant);
        if( requestCode == DEFINE.REGISTER_BEGIN && resultCode == DEFINE.REGISTER_END) {
            //data就是下一个页面的意图
            this.sendBackANDFinish(intant.getParcelableExtra("userObject_RG2LG"));
        }
    }

    private void ToastShow(String content){
        Toast.makeText(LoginActivity.this,content,Toast.LENGTH_SHORT).show();
    }
    private void LogInfo(String info){
        Log.i("loginLog",info);
    }



}
