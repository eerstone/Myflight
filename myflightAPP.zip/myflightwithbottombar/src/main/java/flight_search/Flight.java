package flight_search;


import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

public class Flight implements Parcelable
{
    private String flight_id;

    private String company;

    private String plan_departure_time;

    private String plan_arrival_time;

    private String actual_departure_time;

    private String actual_arrival_time;

    private String flight_status;

    private String departure;

    private String arrival;

    private String punctuality_rate;

    private String delay_time;

    private String check_in;

    private String boarding_port;

    private String arriving_port;

    private String Baggage_num;

    private String depTB;

    private String arrTB;

    public void setFlight_id(String flight_id){
        this.flight_id = flight_id;
    }
    public String getFlight_id(){
        return this.flight_id;
    }
    public void setCompany(String company){
        this.company = company;
    }
    public String getCompany(){
        return this.company;
    }
    public void setPlan_departure_time(String plan_departure_time){
        this.plan_departure_time = plan_departure_time;
    }
    public String getPlan_departure_time(){
        return this.plan_departure_time;
    }
    public void setPlan_arrival_time(String plan_arrival_time){
        this.plan_arrival_time = plan_arrival_time;
    }
    public String getPlan_arrival_time(){
        return this.plan_arrival_time;
    }
    public void setActual_departure_time(String actual_departure_time){
        this.actual_departure_time = actual_departure_time;
    }
    public String getActual_departure_time(){
        return this.actual_departure_time;
    }
    public void setActual_arrival_time(String actual_arrival_time){
        this.actual_arrival_time = actual_arrival_time;
    }
    public String getActual_arrival_time(){
        return this.actual_arrival_time;
    }
    public void setFlight_status(String flight_status){
        this.flight_status = flight_status;
    }
    public String getFlight_status(){
        return this.flight_status;
    }
    public void setDeparture(String departure){
        this.departure = departure;
    }
    public String getDeparture(){
        return this.departure;
    }
    public void setArrival(String arrival){
        this.arrival = arrival;
    }
    public String getArrival(){
        return this.arrival;
    }
    public void setPunctuality_rate(String punctuality_rate){
        this.punctuality_rate = punctuality_rate;
    }
    public String getPunctuality_rate(){
        return this.punctuality_rate;
    }
    public void setDelay_time(String delay_time){
        this.delay_time = delay_time;
    }
    public String getDelay_time(){
        return this.delay_time;
    }
    public void setCheck_in(String check_in){
        this.check_in = check_in;
    }
    public String getCheck_in(){
        return this.check_in;
    }
    public void setBoarding_port(String boarding_port){
        this.boarding_port = boarding_port;
    }
    public String getBoarding_port(){
        return this.boarding_port;
    }
    public void setArriving_port(String arriving_port){
        this.arriving_port = arriving_port;
    }
    public String getArriving_port(){
        return this.arriving_port;
    }
    public void setBaggage_num(String Baggage_num){
        this.Baggage_num = Baggage_num;
    }
    public String getBaggage_num(){
        return this.Baggage_num;
    }
    public void setDepTB(String deptb){
        this.depTB = deptb;
    }
    public String getDepTB(){
        return this.depTB;
    }
    public void setArrTB(String arrtb){
        this.arrTB = arrtb;
    }
    public String getArrTB(){
        return this.arrTB;
    }





    @Override
    public void writeToParcel(Parcel dest, int flags) {
        Log.i("FlightParcelMSG", "ParcelableCartoon::writeToParcel");
        dest.writeString(flight_id);
        dest.writeString( company);
        dest.writeString( plan_departure_time);
        dest.writeString( plan_arrival_time);
        dest.writeString( actual_departure_time);
        dest.writeString( actual_arrival_time);
        dest.writeString( flight_status);
        dest.writeString( departure);
        dest.writeString( arrival);
        dest.writeString( punctuality_rate);
        dest.writeString( delay_time);
        dest.writeString( check_in);
        dest.writeString( boarding_port);
        dest.writeString( arriving_port);
        dest.writeString( Baggage_num);
        dest.writeString( depTB);
        dest.writeString( arrTB);
    }

    public static final Parcelable.Creator<Flight> CREATOR =
            new Parcelable.Creator<Flight>(){
                @Override
                public Flight createFromParcel(Parcel source) {
                    Log.i("UserParcelMSG", "ParcelableCartoon::Parcelable.Creator::createFromParcel");
                    Flight flight = new Flight();
                    flight.setFlight_id(source.readString());
                    flight.setCompany(source.readString());
                    flight.setPlan_departure_time(source.readString());
                    flight.setPlan_arrival_time(source.readString());
                    flight.setActual_departure_time(source.readString());
                    flight.setActual_arrival_time(source.readString());
                    flight.setFlight_status(source.readString());
                    flight.setDeparture(source.readString());
                    flight.setArrival(source.readString());
                    flight.setPunctuality_rate(source.readString());
                    flight.setDelay_time(source.readString());
                    flight.setCheck_in(source.readString());
                    flight.setBoarding_port(source.readString());
                    flight.setArriving_port(source.readString());
                    flight.setBaggage_num(source.readString());
                    flight.setDepTB(source.readString());
                    flight.setArrTB(source.readString());
                    return flight;
                }

                @Override
                public Flight[] newArray(int size) {
                    Log.i("UserParcelMSG", "ParcelableCartoon::Parcelable.Creator::newArray");
                    return new Flight[size];
                }

            };
    @Override
    public int describeContents() {
        return 0;
    }

}

