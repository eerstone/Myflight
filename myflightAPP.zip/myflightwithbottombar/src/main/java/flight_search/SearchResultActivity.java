package flight_search;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myflightwithbottombar.R;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.LinkedList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import source.DEFINE;

public class SearchResultActivity extends AppCompatActivity implements FlightAdapter.Callback{

    private TextView tv_title;
    private TextView tv_date;
    private ListView lv_flight;
    private String cityFrom;
    private String cityTo;
    private String date;

    private String responseData = "";

    private static final int FIRST = 0;

    private LinkedList<Flight> Flights;

    private void init(){
        Flights = new LinkedList<Flight>();
        tv_title = (TextView)findViewById(R.id.tv_title);
        tv_date = (TextView)findViewById(R.id.tv_date);
        lv_flight = (ListView)findViewById(R.id.search_list);
        Bundle bundle = getIntent().getExtras();
        cityFrom = bundle.getString("cityfrom");
        cityTo = bundle.getString("cityto");
        date = bundle.getString("date");
        tv_title.setText(cityFrom+"-"+cityTo);
        tv_date.setText(date);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (getSupportActionBar() != null){
            getSupportActionBar().hide();
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flight_search_result);
        init();
        getFlight();


    }
    private void showFlightList(){

        FlightAdapter FA = new FlightAdapter(Flights,this,this::click);
        lv_flight.setAdapter(FA);
    }

    private void getFlight(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Request request = new Request.Builder()
                            .url(DEFINE.serve_addr+DEFINE.searchflightbycityAPI+"?city_from="+ URLEncoder.encode(cityFrom,"utf-8")+
                                    "&city_to="+URLEncoder.encode(cityTo,"utf-8")+
                                    "&datetime="+date)
                            .build();

                    OkHttpClient client = new OkHttpClient();
                    LogInfo(request.url().toString());
                    LogInfo(URLDecoder.decode(request.url().toString(),"utf-8"));
                    LogInfo(request.method());
                    Response response = null;
                    response = client.newCall(request).execute();
                    if(response.isSuccessful()){
                        LogInfo("Flight Connect successful!");
                        //System.out.println("connect successful!");
                    }
                    else{
                        LogInfo("fail to Flight Connect!");
                        throw new IOException("Unexpected Code"+response);
                    }
                    //response 法
                    Message msg = mHandler.obtainMessage();
                    responseData = response.body().string();
                    //responseReader = response.body().charStream();
                    msg.what = FIRST;
                    mHandler.sendEmptyMessage(msg.what);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            try{
                switch(msg.what){
                    case FIRST:
                        //responseData = (String) msg.obj;
                        responseData = URLDecoder.decode(responseData, "utf-8");
                        //RB.setText(responseData);
                        JSONObject rootObject = new JSONObject(responseData);
                        int is_exited =rootObject.getInt("is_exist");
                        if (is_exited==1) {
                            JSONArray flightArray = rootObject.getJSONArray("flight");
                            Gson gs = new Gson();
                            int i;
                            for(i=0;i<flightArray.length();i++){
                                Flight temp = gs.fromJson(flightArray.getJSONObject(i).toString(),
                                        Flight.class);
                                Flights.add(temp);
                            }
                            showFlightList();
                            //json_handle(rootObject);

                        } else {
                            ToastShow("航班不存在");
                            finish();
                        }
                        break;
                    default:
                        break;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return false;
        }
    });

    @Override
    public void click(int pos){
        Intent intent = new Intent(this, SingleFlightActivity.class);
        Bundle bundle = new Bundle();
        bundle.putParcelable("flightObject_FL2SF",Flights.get(pos));
        intent.putExtras(bundle);
        startActivity(intent);
    }
    private void ToastShow(String content){
        Toast.makeText(SearchResultActivity.this,content,Toast.LENGTH_SHORT).show();
    }
    private void LogInfo(String info){
        Log.i("flightSearchLog",info);
    }

}
