package flight_search;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.myflightwithbottombar.R;

import java.util.LinkedList;
import java.util.List;

public class FlightAdapter extends BaseAdapter  {
    private List<Flight> items;
    private Context mContext;
    private Callback mCallback;
    private int pos;
    private MyListener myListener = null;

    public FlightAdapter(LinkedList<Flight> its, Context mC,Callback mc){
        this.items = its;
        this.mContext = mC;
        this.mCallback = mc;
    }
    @Override
    public int getCount(){
        return items.size();
    }
    @Override
    public Object getItem(int position){
        return null;
    }
    @Override
    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        ViewHolder holder = null;
        if (convertView==null){
            convertView = LayoutInflater.from(mContext).inflate(R.layout.item_flight,parent,false);
            holder = new ViewHolder();

            myListener=new MyListener(position);
            holder.tv_no_com =        (TextView)convertView.findViewById(R.id.flight_no_com);
            holder.tv_dep =           (TextView)convertView.findViewById(R.id.dep);
            holder.tv_plan_dep_time = (TextView)convertView.findViewById(R.id.plan_dep_time);
            holder.tv_status =        (TextView)convertView.findViewById(R.id.status);
            holder.tv_plan_arr_time = (TextView)convertView.findViewById(R.id.plan_arr_time);
            holder.tv_arr =           (TextView)convertView.findViewById(R.id.arr);
            holder.bt_to_details =    (Button)convertView.findViewById(R.id.bt_details);

            convertView.setTag(holder);
        }else {
            holder = (ViewHolder)convertView.getTag();
        }
        holder.tv_no_com.setText(items.get(position).getFlight_id()+" "+items.get(position).getCompany());
        holder.tv_dep.setText(items.get(position).getDeparture());
        holder.tv_plan_dep_time.setText(items.get(position).getPlan_departure_time());
        holder.tv_status.setText(items.get(position).getFlight_status());
        holder.tv_plan_arr_time.setText(items.get(position).getPlan_arrival_time());
        holder.tv_arr.setText(items.get(position).getArrival());
        pos = position;
        holder.bt_to_details.setOnClickListener(myListener);
        return convertView;
    }

    static class ViewHolder{
        TextView tv_no_com;
        TextView tv_plan_dep_time;
        TextView tv_dep;
        TextView tv_status;
        TextView tv_plan_arr_time;
        TextView tv_arr;
        Button bt_to_details;
    }


    private class MyListener implements View.OnClickListener {
        int mPosition;
        public MyListener(int inPosition){
            mPosition= inPosition;
        }
        @Override
        public void onClick(View v) {
            mCallback.click(mPosition);
        }

    }
    public interface Callback {
         public void click(int pos);
    }


}