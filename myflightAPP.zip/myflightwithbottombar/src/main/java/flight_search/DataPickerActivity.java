package flight_search;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.DatePicker;
import android.widget.Toast;

import com.example.myflightwithbottombar.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DataPickerActivity extends AppCompatActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (getSupportActionBar() != null){
            getSupportActionBar().hide();
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datepicker);
        DatePicker datePicker = (DatePicker) findViewById(R.id.DatePicker);
        Calendar calendar = Calendar.getInstance();
        /*Intent intent = getIntent();
        Bundle bundle = new Bundle();
        int year = bundle.getInt("year1");
        int monthOfYear = bundle.getInt("month1");
        int dayOfMonth = bundle.getInt("day1");*/
        int year = calendar.get(Calendar.YEAR);
        int monthOfYear = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
        datePicker.init(year, monthOfYear, dayOfMonth, new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                // 获取一个日历对象，并初始化为当前选中的时间
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, monthOfYear, dayOfMonth);
                SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日");
                Toast.makeText(DataPickerActivity.this,format.format(calendar.getTime()),
                        Toast.LENGTH_SHORT).show();
                Intent intent = new Intent();
                Bundle bundle=new Bundle();
                bundle.putInt("year",year);
                bundle.putInt("month",monthOfYear);
                bundle.putInt("day",dayOfMonth);
                intent.putExtras(bundle);
                setResult(0,intent);
                finish();
            }
         });


    }


/*
    @Override
    public void onDateSet(DatePicker view, int year,int month,int day){
        Toast.makeText(MainActivity2.this,"您选择的日期是："+year+"年"+(month+1)+"月"+day+"日!",Toast
                .LENGTH_SHORT).show();
    }*/
}

