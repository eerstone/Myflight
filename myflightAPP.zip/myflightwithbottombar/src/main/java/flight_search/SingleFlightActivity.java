package flight_search;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.example.myflightwithbottombar.R;

public class SingleFlightActivity extends AppCompatActivity {
    Flight flight;
    TextView tv_title;
    TextView tv_com;
    TextView tv_state;
    TextView tv_dep;
    TextView tv_arr;
    TextView tv_dep_title;
    TextView tv_arr_title;
    TextView tv_dep_time;
    TextView tv_arr_time;
    TextView tv_plan_dep_time;
    TextView tv_plan_arr_time;
    TextView tv_checkin;
    TextView tv_boardport;
    TextView tv_arrport;
    TextView tv_luggage;
    TextView tv_punctuality_rate;


    private void init(){
        flight = getIntent().getParcelableExtra("flightObject_FL2SF");
        tv_title = (TextView)findViewById(R.id.title);
        tv_com = (TextView)findViewById(R.id.com);
        tv_state = (TextView)findViewById(R.id.state);
        tv_dep = (TextView)findViewById(R.id.dep);
        tv_arr = (TextView)findViewById(R.id.arr);
        tv_dep_title = (TextView)findViewById(R.id.dep_title);
        tv_arr_title = (TextView)findViewById(R.id.arr_title);
        tv_dep_time = (TextView)findViewById(R.id.dep_time);
        tv_arr_time = (TextView)findViewById(R.id.arr_time);
        tv_plan_dep_time = (TextView)findViewById(R.id.plan_dep_time);
        tv_plan_arr_time = (TextView)findViewById(R.id.plan_arr_time);
        tv_checkin = (TextView)findViewById(R.id.checkin);
        tv_boardport = (TextView)findViewById(R.id.boardport);
        tv_arrport = (TextView)findViewById(R.id.arrport);
        tv_luggage = (TextView)findViewById(R.id.luggage);
        tv_punctuality_rate = (TextView)findViewById(R.id.punctuality_rate);

        tv_title.setText(flight.getFlight_id());
        tv_com.setText(flight.getCompany());
        tv_state.setText(flight.getFlight_status());
        tv_dep.setText(flight.getDeparture());
        tv_arr.setText(flight.getArrival());
        tv_plan_dep_time.setText("计划： "+flight.getPlan_departure_time());
        tv_plan_arr_time.setText("计划： "+flight.getPlan_arrival_time());
        tv_checkin.setText(flight.getCheck_in());
        tv_boardport.setText(flight.getBoarding_port());
        tv_arrport.setText(flight.getArriving_port());
        tv_luggage.setText(flight.getBaggage_num());
        tv_punctuality_rate.setText(flight.getPunctuality_rate());

        //到达航班显示实际时间 其余状态航班显示计划时间
        if(flight.getFlight_status().equals("到达")){
            tv_dep_title.setText("实际：");
            tv_arr_title.setText("实际：");
            tv_dep_time.setText(flight.getActual_departure_time());
            tv_arr_time.setText(flight.getActual_arrival_time());
        }else{
            tv_dep_title.setText("预计：");
            tv_arr_title.setText("预计：");
            tv_dep_time.setText(flight.getPlan_departure_time());
            tv_arr_time.setText(flight.getPlan_arrival_time());
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (getSupportActionBar() != null){
            getSupportActionBar().hide();
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flight_details);
        init();
    }

}
