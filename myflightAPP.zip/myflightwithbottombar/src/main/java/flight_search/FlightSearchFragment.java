package flight_search;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.myflightwithbottombar.R;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.io.IOException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import source.DEFINE;

import static android.content.ContentValues.TAG;


public class FlightSearchFragment extends Fragment {

    private Button no_button ;
    private Button air_button ;
    private EditText depET;
    private EditText arrET;
    private LinearLayout flightno;
    private EditText idET;
    private LinearLayout airport;
    private Button search_button;
    private Button date1_button;//by city
    private Button date2_button;//by id
    private Calendar QueryDate;
    private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    private WayToSearch search_way = WayToSearch.ByNumer;

    private String responseData = "";

    private static final int FIRST = 0;

    public enum WayToSearch{
        ByNumer,
        ByCity
    }

    private void initWidgetsAndVar(View view){
        no_button = (Button) view.findViewById(R.id.button5);
        air_button = (Button) view.findViewById(R.id.button6);
        depET = (EditText) view.findViewById(R.id.departure);
        arrET = (EditText) view.findViewById(R.id.arrive);
        idET = (EditText) view.findViewById(R.id.flightno);
        flightno = (LinearLayout) view.findViewById(R.id.linearLayout4);
        airport = (LinearLayout) view.findViewById(R.id.linearLayout);
        search_button = (Button) view.findViewById(R.id.button_search);
        date1_button = (Button) view.findViewById(R.id.button_date);
        date2_button = (Button) view.findViewById(R.id.button_date2);
        QueryDate = Calendar.getInstance();
        airport.setVisibility(View.GONE);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //不同的Activity对应不同的布局
        View view = inflater.inflate(R.layout.activity_flight_search, container, false);
        initWidgetsAndVar(view);
        date1_button.setText(format.format(QueryDate.getTime()));
        date2_button.setText(format.format(QueryDate.getTime()));
        no_button.setOnClickListener(NoClickListener);
        air_button.setOnClickListener( AirClickListener);
        date1_button.setOnClickListener(dateClickLister);
        date2_button.setOnClickListener(dateClickLister);
        search_button.setOnClickListener(searchClickListener);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    private View.OnClickListener dateClickLister = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(getActivity(), DataPickerActivity.class);
            FlightSearchFragment.this.startActivityForResult(intent,0);
        }
    };


    private View.OnClickListener NoClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            flightno.setVisibility(View.VISIBLE);
            airport.setVisibility(View.GONE);
            search_way = WayToSearch.ByNumer;
        }

    };
    private View.OnClickListener AirClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            flightno.setVisibility(View.GONE);
            airport.setVisibility(View.VISIBLE);
            search_way = WayToSearch.ByCity;
        }

    };

    private void dateChange(int year,int month,int day){

        QueryDate.set(year,month,day);
        String dateString = format.format(QueryDate.getTime());
        date2_button.setText(dateString);
        date1_button.setText(dateString);
    }

    public View.OnClickListener searchClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(search_way == WayToSearch.ByCity){
                Intent intent = new Intent(getActivity(), SearchResultActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("cityfrom",depET.getText().toString().trim());
                bundle.putString("cityto",arrET.getText().toString().trim());
                bundle.putString("date",date1_button.getText().toString().trim());
                intent.putExtras(bundle);
                startActivity(intent);
            }
            else if(search_way == WayToSearch.ByNumer){
                //button2
                String flight_id = idET.getText().toString().trim();
                String date = date2_button.getText().toString().trim();

                final Request request = new Request.Builder()
                        .url(DEFINE.serve_addr+DEFINE.searchflightbyidAPI+"?flight_id="+flight_id+
                                "&datetime="+date)
                        .build();
                final OkHttpClient client = new OkHttpClient();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Response response = null;
                        try {
                            LogInfo(request.method());
                            response = client.newCall(request).execute();
                            if(response.isSuccessful()){
                                LogInfo("Flight Connect successful!");
                                //System.out.println("connect successful!");
                            }
                            else{
                                LogInfo("fail to Flight Connect!");
                                throw new IOException("Unexpected Code"+response);
                            }
                            //response 法
                            Message msg = mHandler.obtainMessage();
                            responseData = response.body().string();
                            //responseReader = response.body().charStream();
                            msg.what = FIRST;
                            mHandler.sendEmptyMessage(msg.what);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
            else {
                Log.e("SearchLog","except search_byCity or search_byId");
            }

        }
    };

    Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            try{
                switch(msg.what){
                    case FIRST:
                        //responseData = (String) msg.obj;
                        responseData = URLDecoder.decode(responseData, "utf-8");
                        //RB.setText(responseData);
                        JSONObject rootObject = new JSONObject(responseData);
                        int is_exited =rootObject.getInt("is_exist");
                        if (is_exited==1) {
                            JSONObject flightOb = rootObject.getJSONArray("flight").getJSONObject(0);
                            Gson gs = new Gson();
                            Flight flight = gs.fromJson(flightOb.toString(), Flight.class);

                            Intent intent = new Intent(getActivity(), SingleFlightActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putParcelable("flightObject_FL2SF",flight);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        } else {
                            ToastShow("航班不存在");
                        }
                        break;
                    default:
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return false;
        }
    });

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==0&&resultCode==0){
            Log.d(TAG,"response success");
            Bundle response = data.getExtras();
            dateChange(response.getInt("year"),response.getInt("month"),response.getInt("day"));
        }
    }
    private void ToastShow(String content){
        Toast.makeText(getActivity(),content,Toast.LENGTH_SHORT).show();
    }
    private void LogInfo(String info){
        Log.i("flightSearchLog",info);
    }
}
