package airport;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myflightwithbottombar.MainActivity2;
import com.example.myflightwithbottombar.R;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.LinkedList;

import flight_search.Flight;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import source.DEFINE;

public class AirportFragment extends Fragment {
    private LinkedList<AirportScreenItem> depASIs;
    private LinkedList<AirportScreenItem> arrASIs;
    private LinkedList<Flight> depFlights;
    private LinkedList<Flight> arrFlights;
    private Spinner sp_airport;
    private TextView tv_aircode;
    private TextView tv_temp;
    private TextView tv_weather;
    private ImageView img_weather;
    private Button bt_update;
    private LinearLayout departure;
    private LinearLayout arrive;
    private Switch showSwitch;
    private ListView listview;

    private String selected_airport;

    private String responseData = "";

    private ItemAdapter depIA;
    private ItemAdapter arrIA;


    private static final int FIRST = 0;

    private void init_Widgets(View view){
        sp_airport = (Spinner)view.findViewById(R.id.sp_airport);
        tv_aircode = (TextView)view.findViewById(R.id.tv_airport_code);
        tv_temp = (TextView)view.findViewById(R.id.tv_temperature);
        tv_weather = (TextView)view.findViewById(R.id.tv_weather);
        img_weather = (ImageView)view.findViewById(R.id.img_weather);
        bt_update = (Button)view.findViewById(R.id.update);
        departure = (LinearLayout)view.findViewById(R.id.departure);
        arrive = (LinearLayout)view.findViewById(R.id.arrive);
        showSwitch = (Switch)view.findViewById(R.id.switch2);
        listview = (ListView)view.findViewById(R.id.list_view);
        depASIs = new LinkedList<AirportScreenItem>();
        arrASIs = new LinkedList<AirportScreenItem>();
        depFlights = new LinkedList<Flight>();
        arrFlights = new LinkedList<Flight>();

        tv_aircode.setVisibility(View.INVISIBLE);
    }
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_airport, container, false);
        this.init_Widgets(view);
        this.spinnerSetting();
        this.SwitchListen();
        bt_update.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    getAirportInfo();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        });
        return view;
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    private void spinnerSetting(){
        /*静态的显示下来出来的菜单选项，显示的数组元素提前已经设置好了
         * 第二个参数：已经编写好的数组
         * 第三个数据：默认的样式
         */
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(getActivity(),
                R.array.airports,
                android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(getActivity(),
                R.array.aircodes,
                android.R.layout.simple_spinner_item);
        //设置spinner中每个条目的样式，同样是引用android提供的布局文件
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_airport.setAdapter(adapter1);
        sp_airport.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        selected_airport = parent.getItemAtPosition(position).toString();
                        tv_aircode.setText(adapter2.getItem(1));
                        //响应刷新界面
                        try {
                            getAirportInfo();
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                    }
                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
    }

    public void getAirportInfo() throws UnsupportedEncodingException {


        new Thread(new Runnable() {
            @Override
            public void run() {

                try {
                    Request request = new Request.Builder()
                            .url(DEFINE.serve_addr+DEFINE.getairportAPI+"?airport="+ URLEncoder.encode(selected_airport,"utf-8"))
                            .build();
                    OkHttpClient client = new OkHttpClient();
                    Response response = null;
                    LogInfo(request.method());
                    response = client.newCall(request).execute();
                    if(response.isSuccessful()){
                        LogInfo("Airport Connect successful!");
                        //System.out.println("connect successful!");
                    }
                    else{
                        LogInfo("fail to Airport Connect!");
                        throw new IOException("Unexpected Code"+response);
                    }
                    //response 法
                    Message msg = mHandler.obtainMessage();
                    responseData = response.body().string();
                    //responseReader = response.body().charStream();
                    msg.what = FIRST;
                    mHandler.sendEmptyMessage(msg.what);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            try{
                switch(msg.what){
                    case FIRST:
                        responseData = URLDecoder.decode(responseData, "utf-8");
                        JSONObject rootObject = new JSONObject(responseData);
                        tv_weather.setText(rootObject.getString("weather"));
                        tv_temp.setText(rootObject.getString("temperature"));
                        JSONArray depflightArray = rootObject.getJSONArray("departure_flights");
                        JSONArray arrflightArray = rootObject.getJSONArray("arrival_flights");
                        Gson gs = new Gson();
                        int i;
                        depASIs.clear();
                        arrASIs.clear();
                        for(i=0;i<depflightArray.length();i++){
                            Flight f = gs.fromJson(depflightArray.getJSONObject(i).toString(), Flight.class);
                            AirportScreenItem temp = new AirportScreenItem(
                                    f.getFlight_id(),
                                    f.getArrival(),
                                    f.getPlan_departure_time(),
                                    f.getActual_departure_time(),
                                    f.getDepTB(),
                                    f.getFlight_status());
                            depASIs.add(temp);
                        }
                        for(i=0;i<arrflightArray.length();i++){
                            Flight f = gs.fromJson(arrflightArray.getJSONObject(i).toString(), Flight.class);
                            AirportScreenItem temp = new AirportScreenItem(
                                    f.getFlight_id(),
                                    f.getDeparture(),
                                    f.getPlan_arrival_time(),
                                    f.getActual_arrival_time(),
                                    f.getArrTB(),
                                    f.getFlight_status());
                            arrASIs.add(temp);
                        }
                        depIA = new ItemAdapter(depASIs,getActivity());
                        arrIA = new ItemAdapter(arrASIs,getActivity());
                        listview.setAdapter(depIA);
                        break;
                    default:
                        break;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return false;
        }
    });


    private void SwitchListen(){
        CompoundButton.OnCheckedChangeListener listener = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    //arrive
                    departure.setVisibility(View.GONE);
                    arrive.setVisibility(View.VISIBLE);
                    listview.setAdapter(arrIA);
                    showSwitch.setChecked(true);
                }
                else{
                    //departure
                    departure.setVisibility(View.VISIBLE);
                    arrive.setVisibility(View.GONE);
                    listview.setAdapter(depIA);
                    showSwitch.setChecked(false);
                }
            }
        };
        showSwitch.setOnCheckedChangeListener(listener);
    }

    private void ToastShow(String content){
        Toast.makeText(getActivity(),content,Toast.LENGTH_SHORT).show();
    }
    private void LogInfo(String info){
        Log.i("AirportLog",info);
    }
}

