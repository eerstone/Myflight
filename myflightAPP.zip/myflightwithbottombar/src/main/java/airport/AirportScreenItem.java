package airport;

public class AirportScreenItem {
    private String flight_no;
    private String city;
    private String planT;
    private String actualT;
    private String TB;
    private String state;
    public AirportScreenItem(){
    }

    public AirportScreenItem(String no,String c,String p,String a,String tb,String fs){
        flight_no = no;
        city = c;
        planT = p;
        actualT = a;
        TB = tb;
        state = fs;
    }


    public String getFlight_no() {
        return flight_no;
    }

    public String getCity(){
        return city;
    }

    public String getPlanT() {
        return planT;
    }

    public String getActualT() {
        return actualT;
    }

    public String getTB() {
        return TB;
    }

    public String getState() {
        return state;
    }
}
