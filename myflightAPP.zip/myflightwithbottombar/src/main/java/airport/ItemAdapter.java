package airport;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.myflightwithbottombar.R;

import java.util.LinkedList;
import java.util.List;


public class ItemAdapter extends BaseAdapter {
    private List<AirportScreenItem> items;
    private Context mContext;

    public ItemAdapter(LinkedList<AirportScreenItem> its,Context mC){
        this.items = its;
        this.mContext = mC;
    }
    @Override
    public int getCount(){
        return items.size();
    }
    @Override
    public Object getItem(int position){
        return null;
    }
    @Override
    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        ViewHolder holder = null;
        if (convertView==null){
            convertView = LayoutInflater.from(mContext).inflate(R.layout.item_airportscreen,parent,false);
            holder = new ViewHolder();
            holder.tv1 = (TextView)convertView.findViewById(R.id.item_as_1);
            holder.tv2 = (TextView)convertView.findViewById(R.id.item_as_2);
            holder.tv3 = (TextView)convertView.findViewById(R.id.item_as_3);
            holder.tv4 = (TextView)convertView.findViewById(R.id.item_as_4);
            holder.tv5 = (TextView)convertView.findViewById(R.id.item_as_5);
            holder.tv6 = (TextView)convertView.findViewById(R.id.item_as_6);
            convertView.setTag(holder);
        }else {
            holder = (ViewHolder)convertView.getTag();
        }
        holder.tv1.setText(items.get(position).getFlight_no());
        holder.tv2.setText(items.get(position).getCity());
        holder.tv3.setText(items.get(position).getPlanT().toString());
        holder.tv4.setText(items.get(position).getActualT().toString());
        holder.tv5.setText(items.get(position).getTB());
        holder.tv6.setText(items.get(position).getState().toString());
        return convertView;
    }

    static class ViewHolder{
        TextView tv1;
        TextView tv2;
        TextView tv3;
        TextView tv4;
        TextView tv5;
        TextView tv6;
    }

}
