package backups;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.example.myflightwithbottombar.R;

public class AirportActivity extends AppCompatActivity {
    private LinearLayout departure;
    private LinearLayout arrive;
    private Switch showSwitch;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_airport);
        departure = (LinearLayout)findViewById(R.id.departure);
        arrive = (LinearLayout)findViewById(R.id.arrive);
        showSwitch = (Switch)findViewById(R.id.switch2);
        this.showSwitchListen();
    }

    private void showSwitchListen(){
        CompoundButton.OnCheckedChangeListener listener = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    //arrive
                    departure.setVisibility(View.GONE);
                    arrive.setVisibility(View.VISIBLE);
                    showSwitch.setChecked(true);
                }
                else{
                    //departure
                    departure.setVisibility(View.VISIBLE);
                    arrive.setVisibility(View.GONE);
                    showSwitch.setChecked(false);
                }
            }
        };
        showSwitch.setOnCheckedChangeListener(listener);
    }

}
