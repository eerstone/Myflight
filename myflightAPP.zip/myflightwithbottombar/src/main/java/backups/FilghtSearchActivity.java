package backups;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.support.constraint.ConstraintSet;

import com.example.myflightwithbottombar.R;


public class FilghtSearchActivity extends AppCompatActivity {
    private LinearLayout flightno;
    private LinearLayout airport;
    private Button search;
    private ConstraintSet ConsSet = new ConstraintSet();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flight_search);
        flightno =(LinearLayout) findViewById(R.id.linearLayout4);
        airport =(LinearLayout) findViewById(R.id.linearLayout);
    }

    /*@Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //不同的Activity对应不同的布局
        View view = inflater.inflate(R.layout.activity_flight_search, container, false);

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        flightno =(LinearLayout) getView().findViewById(R.id.linearLayout4);
        activity_airport =(LinearLayout)getView().findViewById(R.id.linearLayout);
        search =(Button)getView().findViewById(R.id.button_search);

    }*/

    public void No_click(View view) {
        flightno.setVisibility(View.VISIBLE);
        airport.setVisibility(View.GONE);
    }
    public void Air_click(View view) {
        flightno.setVisibility(View.GONE);
        airport.setVisibility(View.VISIBLE);
    }
}
