package backups;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.myflightwithbottombar.R;

public class PersonalCenterActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_center);
    }
}
