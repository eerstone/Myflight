package com.example.myflightwithbottombar;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
;

import airport.AirportFragment;
import flight_search.FlightSearchFragment;
import personal_center.LoginActivity;
import personal_center.PersonalCenterFragment;
import personal_center.User;
import source.DEFINE;


public class MainActivity2 extends AppCompatActivity implements PersonalCenterFragment.MyQuitListener {
    private BottomNavigationView navigation;
    private Fragment fragment1;
    private Fragment fragment2;
    private Fragment fragment3;
    private Fragment[] fragments;
    static private Fragment [] sfs;
    private int lastfragment;
    static private boolean isLogin = false;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (getSupportActionBar() != null){
            getSupportActionBar().hide();
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initFragment();

    }


    private void initFragment() {
        fragment1 = new FlightSearchFragment();
        fragment2 = new AirportFragment();
        fragment3 = new Fragment();
        fragments = new Fragment[]{fragment1, fragment2, fragment3};
        lastfragment = 0;
        getSupportFragmentManager().beginTransaction().replace(R.id.FLM, fragment1).commit();
        navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }
    //private TextView mTextMessage;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home: {
                    if (lastfragment != 0) {
                        /*TextView tv = (TextView)findViewById(R.id.mainView);
                        tv.setVisibility(View.GONE);*/
                        switchFragment(lastfragment, 0);
                        lastfragment = 0;
                    }
                    return true;
                }
                case R.id.navigation_dashboard: {
                    if (lastfragment != 1) {
                       /* TextView tv = (TextView)findViewById(R.id.mainView);
                        tv.setVisibility(View.GONE);*/
                        switchFragment(lastfragment, 1);
                        lastfragment = 1;
                    }
                    return true;
                }
                case R.id.navigation_notifications: {
                    if (lastfragment != 2) {
                        if(isLogin){
                            Log.i("MainLOG","running at 1");
                            switchFragment(lastfragment, 2);
                            lastfragment = 2;
                        }
                        else{
                            Log.i("MainLOG","running at 2");
                            Intent intent = new Intent();
                            intent.setClass(MainActivity2.this, LoginActivity.class);
                            startActivityForResult(intent, DEFINE.LOGIN_BEGIN);
                            /*fragment3 = new Fragment();
                            fragments[2]=fragment3;
                            switchFragment(lastfragment,2);
                            lastfragment = 2;*/
                        }

                    }
                    return true;
                }

            }
            return false;
        }
    };



    //切换Fragment
    private void switchFragment(int lastfragment, int index) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.hide(fragments[lastfragment]);//隐藏上个Fragment
        if (!fragments[index].isAdded()) {
            transaction.add(R.id.FLM, fragments[index]);
        }
        transaction.show(fragments[index]).commitAllowingStateLoss();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intant) {
        super.onActivityResult(requestCode, resultCode, intant);
        if( requestCode==DEFINE.LOGIN_BEGIN && resultCode==DEFINE.LOGIN_END ) {
            //data就是下一个页面的意图
            Log.i("MainLOG","running at 3");
            user = intant.getParcelableExtra("userObject_LG2M");
            fragment3 = new PersonalCenterFragment();
            Bundle bundle=new Bundle();
            bundle.putParcelable("userObject_M2PC",user);
            fragment3.setArguments(bundle);
            fragments[2] = fragment3;
            switchFragment(lastfragment, 2);
            lastfragment = 2;
        }
    }

    public void restartLoginActivity() {
        Intent intent = new Intent();
        intent.setClass(MainActivity2.this, LoginActivity.class);
        startActivityForResult(intent,10);
    }

    static public void  setLoginFlagOn(){
        isLogin = true;
    }
    static public void  setLoginFlagOFF(){
        isLogin = false;
    }

    @Override
    public void onBackPressed() {
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        home.addCategory(Intent.CATEGORY_HOME);
        startActivity(home);
    }




}
