package source;

import java.net.URLEncoder;

public class DEFINE {
    public static final int LOGIN_BEGIN = 10;
    public static final int LOGIN_END = 11;
    public static final int REGISTER_BEGIN = 12;
    public static final int REGISTER_END = 13;
    public static final int USERINFO_BEGIN = 14;
    public static final int USERINFO_END = 15;
    public static final String serve_addr = "http://114.115.134.188:8088";
    public static final String getairportAPI = "/airport/getAirportInfo/";
    public static final String modifyUserInfoAPI = "/user/postBasicInfo/";
    public static final String registerAPI = "/user/postRegister/";
    public static final String verifyAPI = "/user/postVerifiedCode/";
    public static final String loginAPI = "/user/postLogin/";
    public static final String searchflightbycityAPI = "/airplane/getSearchFlightByCity/";
    public static final String searchflightbyidAPI = "/airplane/getSearchFlightById/";
}
