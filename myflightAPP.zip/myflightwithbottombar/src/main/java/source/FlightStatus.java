package source;

public enum FlightStatus {
    Plan,
    Dalay_warning,
    Dalayed,
    Cancel,
    Checking_in,
    OnBoarding,
    OnBoard_end,
    Taking_off,
    Arrived
}
